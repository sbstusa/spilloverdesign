if (require(testthat)) {
  library(RItools)
  test_package("RItools")  
}
